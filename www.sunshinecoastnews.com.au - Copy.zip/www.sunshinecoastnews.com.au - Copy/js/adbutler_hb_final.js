AdButlerHB.cmd.push(function () {
  AdButlerHB.requestAuctions();
});
