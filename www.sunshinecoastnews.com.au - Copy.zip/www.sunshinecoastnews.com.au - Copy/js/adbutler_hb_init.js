var AdButlerHB = AdButlerHB || {};
AdButlerHB.cmd = AdButlerHB.cmd || [];
